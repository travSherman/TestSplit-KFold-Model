# Test-Spilt-K-Fold-Algorithm
Uses a Pima-Indian diabetes dataset to analyze data
